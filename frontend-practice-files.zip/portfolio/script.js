<!-- script.js for portfolio -->
