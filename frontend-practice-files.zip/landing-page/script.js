<!-- script.js for landing-page -->
